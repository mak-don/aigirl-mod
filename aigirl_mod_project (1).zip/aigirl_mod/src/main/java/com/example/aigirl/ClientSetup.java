package com.example.aigirl;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AiGirlMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(AiGirlMod.AI_GIRL.get(), Renderer::new);
    }

    public static class Renderer extends HumanoidMobRenderer<AiGirlEntity, PlayerModel<AiGirlEntity>> {
        private static final ResourceLocation TEX =
                new ResourceLocation(AiGirlMod.MODID, "textures/entity/ai_girl.png");

        public Renderer(EntityRendererProvider.Context ctx) {
            super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER_SLIM), true), 0.5F);
        }

        @Override
        public ResourceLocation getTextureLocation(AiGirlEntity entity) {
            return TEX;
        }
    }
}
