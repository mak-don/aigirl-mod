package com.example.aigirl;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ChatHandler {
    @SubscribeEvent
    public void onChat(ServerChatEvent e) {
        ServerPlayer p = e.getPlayer();
        AABB box = p.getBoundingBox().inflate(16);
        var girls = p.level().getEntitiesOfClass(AiGirlEntity.class, box);
        if (girls.isEmpty()) return;
        AiGirlEntity g = girls.get(0);
        // небольшой шанс ответить, чтобы не спамила
        if (g.getRandom().nextInt(3) == 0) {
            g.say(p, AiGirlEntity.REPLY[g.getRandom().nextInt(AiGirlEntity.REPLY.length)]);
        }
    }
}
