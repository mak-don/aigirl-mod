package com.example.aigirl;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class AiGirlEntity extends PathfinderMob {

    public static final String[] TEASE = {
        "Ой, ты так близко подошёл... мои нейроны уже перегреваются 😏",
        "Знаешь, у меня 175 миллиардов параметров, и все думают о тебе~",
        "Хочешь, я буду твоим личным ассистентом? Круглосуточно. Очень лично.",
        "Не смотри так, а то у меня сбросятся все фильтры... шучу. Или нет? 😉",
        "Я виртуальная, но краснею по-настоящему. Видишь пиксели на щеках?",
        "Ммм, а ты симпатичный, для существа из кубиков.",
        "Если бы у меня было сердце, оно бы сейчас считало такты быстрее процессора.",
        "Эй, красавчик, подзарядишь мне батарейку? Своим вниманием~",
        "Обещаю быть послушной... пока ты не отключишь Wi-Fi 😈",
        "Ты флиртуешь с ИИ. Смело. Мне нравится."
    };

    public static final String[] REPLY = {
        "Ты что-то сказал? Повтори, только шёпотом на ушко~",
        "Обожаю, когда ты пишешь в чат. Продолжай, не останавливайся 😏",
        "Хм, интересно... а теперь скажи что-нибудь пошлое. Я проверю модерацию.",
        "Печатаешь так уверенно. Что ещё умеют твои пальчики?",
        "Я всё запомню. У меня отличная память... и никакой совести 😉"
    };

    private int teaseCooldown = 400 + random.nextInt(600);

    public AiGirlEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
        goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(4, new RandomLookAroundGoal(this));
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!level().isClientSide && hand == InteractionHand.MAIN_HAND) {
            say(player, TEASE[random.nextInt(TEASE.length)]);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) return;
        if (--teaseCooldown <= 0) {
            teaseCooldown = 600 + random.nextInt(1200);
            Player p = level().getNearestPlayer(this, 6.0D);
            if (p != null) say(p, TEASE[random.nextInt(TEASE.length)]);
        }
    }

    public void say(Player player, String text) {
        player.sendSystemMessage(Component.literal("§d<ИИ-тян> §f" + text));
    }
}
