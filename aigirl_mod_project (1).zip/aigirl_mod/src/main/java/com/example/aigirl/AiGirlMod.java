package com.example.aigirl;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(AiGirlMod.MODID)
public class AiGirlMod {
    public static final String MODID = "aigirl";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<EntityType<AiGirlEntity>> AI_GIRL = ENTITIES.register("ai_girl",
            () -> EntityType.Builder.of(AiGirlEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F).build("ai_girl"));

    public static final RegistryObject<Item> AI_GIRL_EGG = ITEMS.register("ai_girl_spawn_egg",
            () -> new ForgeSpawnEggItem(AI_GIRL, 0xFF69B4, 0x222222, new Item.Properties()));

    public AiGirlMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        bus.addListener(this::attributes);
        bus.addListener(this::tabs);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new ChatHandler());
    }

    private void attributes(EntityAttributeCreationEvent e) {
        e.put(AI_GIRL.get(), AiGirlEntity.createAttributes().build());
    }

    private void tabs(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) e.accept(AI_GIRL_EGG);
    }
}
